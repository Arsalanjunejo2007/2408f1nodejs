import mongoose from "mongoose";

const db=async ()=>{
    await mongoose.connect("mongodb://localhost:27017/mernclassapi")
console.log("bd connceted")

}

export default db

