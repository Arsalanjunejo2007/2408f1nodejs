import {Router} from "express"
import adminRoutes from "./routes/adminRoutes.js"
import { contact,  deletepage, home, updatepage, userpage } from "./controllers/userController.js"
const router=Router()


router.post("/",userpage)
router.use("/admin",adminRoutes)
router.get("/user",home)
router.post("/contact",contact)
router.put("/update",updatepage)
router.delete("/delete",deletepage)

export default router