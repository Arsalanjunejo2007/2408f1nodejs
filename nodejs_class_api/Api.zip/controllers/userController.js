import usermodel from "../models/userModel.js";

export const userpage = async (req, res) => {
    try {
        const user = await usermodel.find();

        res.status(200).json({
            data: user
        });
    } catch (error) {
        res.status(500).json({
            msg: "db not available"
        });
    }
};


export const home =  async(req, res) => {
    // console.log(req.body)
    // res.end("Welcome to the Home Page!");

    try {
         const user=new  usermodel(req.body);
    await user.save();
    res.status(201).json({msg: "user create successful"})
    } catch (error) {
    res.status(500).json({msg: "validation failed",reason: error })
        
    }
}

export const contact = (req, res) => {
    res.end(" Create Page!");
}

export const updatepage = (req, res) => {
    res.end(" update Page!");
}

export const deletepage = (req, res) => {
    res.end(" delete Page!");
}