import {Schema,model} from "mongoose";

const userschma =new  Schema({
name:{
    type : String,
    required:[true,"name is required "]
},
email:
{
    type: String,
    required:[true , "email is required"],
match: [
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
            "Please enter a valid email"
        ]
},
password:{
    type: String,
 required: true,
  minlength: 8,
  match: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/
},
gender:{
    type:String,
    enum:["Male" , "Female"]
}


})




const usermodel = model("users", userschma)
export default usermodel