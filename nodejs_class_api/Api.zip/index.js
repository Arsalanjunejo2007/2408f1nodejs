import express from "express"
import router from "./router.js"
import db from "./db/db.js"

const server=express()
server.use(express.json())
server.use(router)


await db()
server.listen(7000,()=>{
    console.log("server runing")
})