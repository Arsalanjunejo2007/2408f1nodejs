import {Router} from "express"
import { contact, home, index } from "../controllers/userController.js"
const userRoutes=Router()


userRoutes.get("/", index)

userRoutes.get("/home",home)

userRoutes.get("/contact",contact)

export default userRoutes